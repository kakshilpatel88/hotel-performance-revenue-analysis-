# Hotel Performance & Revenue Analysis

## Project overview
This portfolio project analyzes a sample hotel booking dataset using spreadsheet analysis, BigQuery SQL, Python (Pandas), and Power BI planning assets. The supplied sample contains 30 bookings across January and February 2025.

## Repository structure
- `01_Dataset/` — original and cleaned sample data and the source workbook.
- `02_SQL_Analysis/` — BigQuery SQL queries and query-results workbook.
- `03_Python_Analysis/` — Jupyter notebooks, Python analysis outputs, KPI tables, and validation results.
- `04_PowerBI_Dashboard/` — dashboard previews, layout guide, DAX measures, and theme.
- `05_Project_Report/` — project validation summary.

## Tools
Google Sheets / Excel, Google BigQuery SQL, Python, Pandas, Matplotlib, Power BI.

## Key sample results
- Total bookings: 30
- Stayed bookings: 24
- Cancelled bookings: 6
- Cancellation rate: 20%
- Total realized revenue: $13,640.72
- Occupied room nights: 86
- Realized ADR: $158.61 (total actual revenue divided by occupied room nights)

## Important Power BI note
This repository includes Power BI dashboard design assets, a layout guide, DAX measures, and static chart previews. A completed interactive `.pbix` report is not included yet; add `Hotel_Performance_Revenue_Dashboard.pbix` to `04_PowerBI_Dashboard/` after creating and saving it in Power BI Desktop.

## Data privacy
Before making this repository public, verify that the sample dataset and workbook contain no personal guest information, payment data, or confidential business information, and that you have permission to share them. Remove or anonymize any sensitive fields before publishing.

## How to explore
1. Start with the cleaned CSV in `01_Dataset/`.
2. Review SQL queries in `02_SQL_Analysis/`.
3. Open the `.ipynb` notebooks in Jupyter or Google Colab.
4. Review the Power BI layout guide and DAX measures in `04_PowerBI_Dashboard/`.
